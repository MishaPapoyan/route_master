import {createSlice, createAsyncThunk} from "@reduxjs/toolkit";
import axios from "axios";

// Thunks (async actions)

export const fetchDrivers = createAsyncThunk(
    'drivers/fetchDrivers',
    async () => {
        const res = await axios.get('http://localhost:5000/api/drivers');
        return res.data;
    }
);

export const addDriver = createAsyncThunk(
    'drivers/addDriver',
    async (driverData) => {
        const res = await axios.post('http://localhost:5000/api/drivers', driverData);
        return res.data;
    }
);

export const deleteDriver = createAsyncThunk(
    'drivers/deleteDriver',
    async (id) => {
        await axios.delete(`http://localhost:5000/api/drivers/${id}`);
        return id;
    }
)

export const updateDriver = createAsyncThunk(
    'drivers/updateDriver',
    async ({ id, data }) => {
        const res = await axios.put(`http://localhost:5000/api/drivers/${id}`, data);
        return res.data;
    }
);

export const updateDriverClick = createAsyncThunk(
    'drivers/updateClick',
    async ({ id, type, change }) => {
        const res = await axios.put(`http://localhost:5000/api/drivers/${id}/click`, { type, change });
        return res.data;
    }
);
const driverSlice = createSlice({
    name: "drivers",
    initialState: {
        list: [],
        loading: false,
        error: false,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            // Fetch
            .addCase(fetchDrivers.pending, (state) => {
                state.loading = false;
                state.error = null;
            })
            .addCase(fetchDrivers.fulfilled, (state, action) => {
                state.loading = false;
                state.list = action.payload;
            })
            .addCase(fetchDrivers.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            })

            // Add
            .addCase(addDriver.fulfilled, (state, action) => {
                state.list.push(action.payload);
            })

            // Delete
            .addCase(deleteDriver.fulfilled, (state, action) => {
                state.list = state.list.filter(driver => driver.id !== action.payload);
            })
            .addCase(updateDriver.fulfilled, (state, action) => {

                const updatedDriver = action.payload;
                const index = state.list.findIndex(driver => driver.id === updatedDriver.id);
                if (index !== -1) {
                    // 🔐 Preserve position
                    state.list[index] = {
                        ...state.list[index], // keep previous position data
                        ...updatedDriver      // overwrite updated fields
                    };
                }
            })
            .addCase(updateDriverClick.fulfilled, (state, action) => {
                const index = state.list.findIndex(d => d.id === action.payload.id);
                if (index !== -1) {
                    state.list[index] = {
                        ...state.list[index],
                        ...action.payload
                    };
                }
            });


    }
})

export default driverSlice.reducer;
