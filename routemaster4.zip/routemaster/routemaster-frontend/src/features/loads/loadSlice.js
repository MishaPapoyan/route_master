import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchLoads = createAsyncThunk('loads/fetchLoads', async () => {
    const response = await axios.get('/api/loads');
    return response.data;
});

export const createLoad = createAsyncThunk('loads/createLoad', async (loadData) => {
    const response = await axios.post('/api/loads', loadData);
    return response.data;
});

export const updateLoad = createAsyncThunk('loads/updateLoad', async ({ id, loadData }) => {
    const response = await axios.put(`/api/loads/${id}`, loadData);
    return response.data;
});

export const deleteLoad = createAsyncThunk('loads/deleteLoad', async (id) => {
    await axios.delete(`/api/loads/${id}`);
    return id;
});

const loadSlice = createSlice({
    name: 'loads',
    initialState: {
        items: [],
        status: 'idle',
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchLoads.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchLoads.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.items = action.payload;
            })
            .addCase(fetchLoads.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(createLoad.fulfilled, (state, action) => {
                state.items.push(action.payload);
            })
            .addCase(updateLoad.fulfilled, (state, action) => {
                const index = state.items.findIndex(load => load.id === action.payload.id);
                if (index !== -1) state.items[index] = action.payload;
            })
            .addCase(deleteLoad.fulfilled, (state, action) => {
                state.items = state.items.filter(load => load.id !== action.payload);
            });
    }
});

export default loadSlice.reducer;