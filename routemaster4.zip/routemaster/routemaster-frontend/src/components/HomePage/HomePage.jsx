import Info from "./Info.jsx";
import Header from "./Header.jsx";

const HomePage = () => {
    return (
        <div className='flex flex-col'>
            <Header />
            <div className=''>
                <Info className='w-1/4'/>
            </div>
        </div>
    );
};

export default HomePage;