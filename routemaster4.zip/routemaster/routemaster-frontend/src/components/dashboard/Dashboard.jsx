import React from 'react'
import Header from "../HomePage/Header.jsx";

function Dashboard() {
    return (
        <div>
            <Header />
            <p className='text-5xl text-center'>Dashboard</p>
        </div>
    )
}

export default Dashboard
