// ✅ LoadForm.jsx - Add/Edit Load Modal
import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useDispatch } from 'react-redux';
import { createLoad, updateLoad } from '../../features/loads/loadSlice';

export default function LoadForm({ isOpen, setIsOpen, editingLoad, setEditingLoad }) {
    const dispatch = useDispatch();

    if (!isOpen) return null;

    const initialValues = editingLoad || {
        origin: '',
        destination: '',
        weight: '',
        rate: '',
        broker: '',
        notes: '',
        company: 'N/A',
        contact_method: 'call',
    };

    const validationSchema = Yup.object({
        origin: Yup.string().required('Origin is required'),
        destination: Yup.string().required('Destination is required'),
        weight: Yup.number().required('Weight is required'),
        rate: Yup.number().required('Rate is required'),
    });

    const handleSubmit = async (values) => {
        if (editingLoad) {
            await dispatch(updateLoad({ id: editingLoad.id, loadData: values }));
        } else {
            await dispatch(createLoad(values));
        }
        setIsOpen(false);
        setEditingLoad(null);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">
                    {editingLoad ? 'Edit Load' : 'Add New Load'}
                </h2>

                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                >
                    <Form className="space-y-4">
                        <div>
                            <label className="block font-medium">Origin</label>
                            <Field name="origin" className="input" />
                            <ErrorMessage name="origin" component="div" className="text-red-500 text-sm" />
                        </div>

                        <div>
                            <label className="block font-medium">Destination</label>
                            <Field name="destination" className="input" />
                            <ErrorMessage name="destination" component="div" className="text-red-500 text-sm" />
                        </div>

                        <div>
                            <label className="block font-medium">Weight (lbs)</label>
                            <Field name="weight" type="number" className="input" />
                            <ErrorMessage name="weight" component="div" className="text-red-500 text-sm" />
                        </div>

                        <div>
                            <label className="block font-medium">Rate ($)</label>
                            <Field name="rate" type="number" className="input" />
                            <ErrorMessage name="rate" component="div" className="text-red-500 text-sm" />
                        </div>

                        <div>
                            <label className="block font-medium">Broker</label>
                            <Field name="broker" className="input" />
                        </div>

                        <div>
                            <label className="block font-medium">Notes</label>
                            <Field name="notes" as="textarea" className="input" />
                        </div>

                        <div>
                            <label className="block font-medium">Company</label>
                            <Field name="company" className="input" placeholder="Company" />
                            <ErrorMessage name="company" component="div" className="text-red-500 text-sm" />
                        </div>

                        <div className="flex justify-end gap-2">
                            <button
                                type="button"
                                onClick={() => {
                                    setIsOpen(false);
                                    setEditingLoad(null);
                                }}
                                className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                            >
                                {editingLoad ? 'Update' : 'Create'}
                            </button>
                        </div>
                    </Form>
                </Formik>
            </div>
        </div>
    );
}
