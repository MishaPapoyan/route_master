import driverReducer from '../features/drivers/driverSlice';
import {configureStore} from "@reduxjs/toolkit";
import loadReducer from '../features/loads/loadSlice'; // ✅ Add this


export const store = configureStore({
    reducer: {
        drivers: driverReducer,
        loads: loadReducer,
    },
});