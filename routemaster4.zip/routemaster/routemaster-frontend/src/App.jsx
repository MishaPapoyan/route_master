import React from 'react'
import LoadCardList from "./components/Loads/LoadCardList.jsx";

function App() {
    return (
        <LoadCardList />
    )
}

export default App
