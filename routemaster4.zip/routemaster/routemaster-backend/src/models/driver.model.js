import { DataTypes } from 'sequelize';

export default (sequelize) => {
    const Driver = sequelize.define('Driver', {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },

        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },

        phone_number: DataTypes.STRING,

        call_count: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        status: {
            type: DataTypes.ENUM('connect', "didn't connect"),
            allowNull: true,
        },
        covered: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },

        connect_count: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },

        didnt_connect_count: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },

        current_location: DataTypes.STRING,
        next_location: DataTypes.STRING,

        is_from_rigz: DataTypes.BOOLEAN,

        rigz_id: {
            type: DataTypes.STRING, // Example: RIGZ-98342
            allowNull: false,        // optional but helpful for external lookups
            unique: true,
        },

        nationality: DataTypes.STRING,
        notes: DataTypes.STRING,

        max_weight_capacity: {
            type: DataTypes.INTEGER, // in pounds
            allowNull: false,
        },

        average_rate: {
            type: DataTypes.DECIMAL,
            allowNull: true,
        },

        preferred_routes: {
            type: DataTypes.ARRAY(DataTypes.STRING), // Example: ['LA → TX', 'TX → LA']
            allowNull: false,
        },


    }, {
        tableName: 'drivers',
        timestamps: true,
    });

    Driver.associate = (models) => {
        Driver.hasMany(models.Load, {
            foreignKey: 'driverId',
            as: 'loads',
        });
    };

    return Driver;
};
