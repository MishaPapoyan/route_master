import db from '../models/index.js';

const Driver = db.Driver;

export const getAllDrivers = async (req, res) => {
    try {
        const drivers = await Driver.findAll();
        res.status(200).json(drivers);
    } catch (err) {
        console.error('❌ Error fetching drivers:', err);
        res.status(500).json({ message: 'Server error while fetching drivers' });
    }
};

export const createDriver = async (req, res) => {
    try {
        const {
            name,
            phone_number,
            call_count,
            current_location,
            next_location,
            is_from_rigz,
            nationality,
            notes,
            rigz_id,
            max_weight_capacity,
            average_rate,
            preferred_routes,
            status, // NEW
            connect_count, // NEW
            didnt_connect_count // NEW
        } = req.body;

        const newDriver = await Driver.create({
            name,
            phone_number,
            call_count,
            current_location,
            next_location,
            is_from_rigz,
            nationality,
            notes,
            rigz_id,
            max_weight_capacity,
            average_rate,
            preferred_routes,
            status,
            connect_count,
            didnt_connect_count
        });

        console.log('✅ Driver created:', newDriver);
        res.status(201).json(newDriver);
    } catch (err) {
        console.error('❌ Error creating driver:', err);
        res.status(500).json({ message: 'Server error while creating driver' });
    }
};

export const updateDriver = async (req, res) => {
    const driverId = req.params.id;

    try{
        const driver = await Driver.findByPk(driverId);
        if (!driver) {
            return res.status(404).json({message: 'Driver not found'});
        }
        await driver.update(req.body);
        res.status(200).json({message: 'Driver updated', driver});
    }catch (err){
        console.error('❌ Error updating driver:', err);
        res.status(500).json({ message: 'Server error while updating driver' });
    }
}

export const deleteDriver = async (req, res) => {
    console.log('Incoming body:', req.body); // <--- Add this

    const driverId = req.params.id;
    try {
        const driver = await Driver.findByPk(driverId);
        if (!driver) {
            return res.status(404).json({message: 'Driver not found'});
        }
        await driver.destroy();
        res.status(200).json({ message: 'Driver deleted successfully', driver });
    } catch (err) {
        console.error('❌ Error deleting driver:', err);
        res.status(500).json({ message: 'Server error while deleting driver' });
    }
}

export const updateCallStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { type, change = 1 } = req.body;

        const driver = await Driver.findByPk(id);
        if (!driver) {
            return res.status(404).json({ message: 'Driver not found' });
        }

        switch (type) {
            case 'call':
                driver.call_count += change;
                break;

            case 'connect':
                driver.connect_count += change;
                driver.status = 'connect';
                break;

            case 'didnt_connect':
                driver.didnt_connect_count += change;
                driver.status = "didn't connect";
                break;

            default:
                return res.status(400).json({ message: 'Invalid update type' });
        }

        await driver.save();
        res.status(200).json(driver);
    } catch (err) {
        console.error('❌ Error updating driver interaction:', err);
        res.status(500).json({ message: 'Server error while updating call status' });
    }
};
