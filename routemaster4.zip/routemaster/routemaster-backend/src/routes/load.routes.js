import express from 'express';
import {
    createLoad,
    deleteLoad,
    getAllLoads,
    updateLoad,
    updateLoadStatus,
    markLoadContacted // ✅ new
} from "../controllers/load.controller.js";

const router = express.Router();

router.get('/', getAllLoads);                     // ✅ GET /api/loads
router.post('/', createLoad);                    // ✅ POST /api/loads
router.put('/:id', updateLoad);                  // ✅ PUT /api/loads/:id
router.delete('/:id', deleteLoad);               // ✅ DELETE /api/loads/:id
router.patch('/:id/status', updateLoadStatus);   // ✅ PATCH /api/loads/:id/status
router.post('/:id/contact', markLoadContacted);  // ✅ POST /api/loads/:id/contact

export default router;
